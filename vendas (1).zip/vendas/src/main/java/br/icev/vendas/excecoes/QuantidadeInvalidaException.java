package br.icev.vendas.excecoes;


public class QuantidadeInvalidaException extends Exception {
    public QuantidadeInvalidaException(String msg) { super(msg); }
}

package br.icev.vendas.excecoes;

public class SemEstoqueException extends Exception {
    public SemEstoqueException(String msg) { super(msg); }
}
